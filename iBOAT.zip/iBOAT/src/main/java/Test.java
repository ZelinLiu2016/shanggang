import com.google.gson.Gson;
import mapreduce.DailyTrajectory;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by cbdog94 on 17-3-7.
 */
public class Test {

    public static class Map extends Mapper<LongWritable, Text, Text, IntWritable> {
        private static IntWritable one = new IntWritable(1);

        @Override
        protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
            //25927,0,0,0,0,0,2015-04-01 20:47:26,2015-04-01 20:47:20,121.535467,31.209523,0.0,201.0,12
            String line = value.toString();
            String[] splits = line.split(",");
            context.write(new Text(splits[0] + " " + splits[2]), one);
        }
    }

    public static class Reduce extends Reducer<Text, IntWritable, Text, IntWritable> {
        @Override
        protected void reduce(Text key, Iterable<IntWritable> values, Context context) throws IOException, InterruptedException {
            int sum = 0;
            for (IntWritable item : values) {
                sum += item.get();
            }
            context.write(key, new IntWritable(sum));
        }
    }

//    public static void main(String[] args) throws Exception {
//        if (args.length < 2) {
//            System.out.println("Please input inputFilePath and outputFilePath!");
//            return;
//        }
//        Job job = Job.getInstance();
//        job.setJobName("Test");
//        job.setJarByClass(Test.class);
//
//        job.setMapperClass(Map.class);
//        job.setReducerClass(Reduce.class);
//
//        job.setInputFormatClass(com.hadoop.mapreduce.LzoTextInputFormat.class);
//        job.setOutputKeyClass(Text.class);
//        job.setOutputValueClass(IntWritable.class);
//
////        job.setNumReduceTasks(1);
//
//        FileInputFormat.addInputPath(job, new Path(args[0]));
//        FileOutputFormat.setOutputPath(job, new Path(args[1]));
//
//        job.waitForCompletion(true);
//    }

    public static void main(String[] args) throws Exception {
        BufferedReader reader = new BufferedReader(new FileReader(new File("/Users/cbdog94/Downloads/part-r-00000")));
        String content = reader.readLine();

        int[] dist = new int[470];
        double max = 0;
        System.out.println();
        while ((content = reader.readLine()) != null) {
            double distance = Double.parseDouble(content.split("\t")[1]);
//            System.out.println((int)distance);
            dist[(int) distance / 1000]++;
        }


        reader.close();
        System.out.println(new Gson().toJson(dist));
//        System.out.println(max);
//        DailyTrajectory.Trajectory trajectory = new Gson().fromJson(content, DailyTrajectory.Trajectory.class);
//        System.out.println(trajectory.taxiId);
//        System.out.println(trajectory.points);
    }
}
