import com.google.gson.Gson;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

/**
 * 测试：转换成Echart数据
 */
public class ForEchart {
    public static void main(String[] args) throws Exception{
        BufferedReader br=new BufferedReader(new InputStreamReader(new FileInputStream("result_sort/part-r-00000")));
        String line=br.readLine();
        List<String> coords=new ArrayList<>();
        while (line!=null){
            String[] splits=line.split("\t");
            // latitude=Double.parseDouble(line.substring(2,11));
            //Double longitude=Double.parseDouble(line.substring(12,22));
            coords.add(splits[2]);
            line=br.readLine();
        }
        br.close();
        String s=new Gson().toJson(coords);
        System.out.println(s);
    }

    static class Container{
        List<String> coords;


    }
}
