for loop in 10 20 30 40 50 60 70 80 90 100 
do
    java -classpath target/iBOAT-1.0.jar app.iBAT $loop 200 
done

for loop in 50 100 200 250 300 400 500 600 800 1000 
do
    java -classpath target/iBOAT-1.0.jar app.iBAT 50 $loop 
done
