package custom;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Partitioner;

/**
 * Created by cbdog94 on 2017/4/6.
 */
public class DefinedPartition extends Partitioner<CombinationKey, Text> {
    @Override
    public int getPartition(CombinationKey combinationKey, Text text, int i) {
        return (combinationKey.getFirstKey().hashCode() & Integer.MAX_VALUE) % i;
    }
}
