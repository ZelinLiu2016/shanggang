package custom;

import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.io.WritableComparator;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by cbdog94 on 2017/4/6.
 */
public class DefinedComparator extends WritableComparator {

    private static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    public DefinedComparator() {
        super(CombinationKey.class, true);
    }

    @Override
    public int compare(WritableComparable a, WritableComparable b) {
        CombinationKey c1 = (CombinationKey) a;
        CombinationKey c2 = (CombinationKey) b;

        if (!c1.getFirstKey().equals(c2.getFirstKey())) {
            return c1.getFirstKey().compareTo(c2.getFirstKey());
        } else {
            try {
                Date d1 = sdf.parse(c1.getSecondKey().toString());
                Date d2 = sdf.parse(c2.getSecondKey().toString());
                return d1.compareTo(d2);
            } catch (Exception e) {
                return 0;
            }
        }
    }
}
