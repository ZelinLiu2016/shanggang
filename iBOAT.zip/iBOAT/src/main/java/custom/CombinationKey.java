package custom;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.WritableComparable;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

/**
 * Created by cbdog94 on 2017/4/6.
 */
public class CombinationKey implements WritableComparable<CombinationKey>{

    private Text firstKey;
    private Text secondKey;

    public Text getFirstKey() {
        return firstKey;
    }

    public void setFirstKey(Text firstKey) {
        this.firstKey = firstKey;
    }

    public Text getSecondKey() {
        return secondKey;
    }

    public void setSecondKey(Text secondKey) {
        this.secondKey = secondKey;
    }

    public CombinationKey(String firstKey, String secondKey) {
        this.firstKey = new Text(firstKey);
        this.secondKey = new Text(secondKey);
    }

    public CombinationKey() {
        this.firstKey = new Text();
        this.secondKey = new Text();
    }

    @Override
    public int compareTo(CombinationKey o) {
        return this.firstKey.compareTo(o.firstKey);
    }

    @Override
    public void write(DataOutput dataOutput) throws IOException {
        this.firstKey.write(dataOutput);
        this.secondKey.write(dataOutput);
    }

    @Override
    public void readFields(DataInput dataInput) throws IOException {
        this.firstKey.readFields(dataInput);
        this.secondKey.readFields(dataInput);
    }
}
