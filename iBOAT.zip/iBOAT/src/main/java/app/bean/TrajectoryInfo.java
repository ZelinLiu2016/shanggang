package app.bean;

import bean.GPS;

import java.util.List;

public class TrajectoryInfo {
    public String taxiId;
    public double score;
    public boolean normal;
    public List<GPS> trajectory;
}
