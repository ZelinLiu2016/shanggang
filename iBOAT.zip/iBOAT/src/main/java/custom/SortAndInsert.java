package custom;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import util.CommonUtil;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

/**
 * Sort by the timestamp of GPS and the taxi,
 * and then grid the GPS to tile point,
 * insert the tile sequence to HBase.
 *
 * @author Bin Cheng
 */
public class SortAndInsert {


    public static class Map extends Mapper<LongWritable, Text, CombinationKey, Text> {
        @Override
        protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
            String line = value.toString();
            //车ID 0,报警,空车 2,顶灯状态,高架mv,刹车,接收时间 6,GPS测定时间 7,经度 8 ,纬度 9,速度,方向,卫星个数
            //25927,0,0,0,0,0,2015-04-01 20:47:26,2015-04-01 20:47:20,121.535467,31.209523,0.0,201.0,12
            String[] splits = line.split(",");
            if (CommonUtil.isValidTimestamp(splits[7])) {
                context.write(new CombinationKey(splits[0],splits[7]), new Text(splits[9] + "," + splits[8] + "," + splits[2] + "," + splits[7]));
            }
        }
    }

    public static class Reduce extends Reducer<CombinationKey, Text, Text,Text> {
        //notice:HH means 24-hour clock, hh means 12-hour clock
        private static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        @Override
        protected void reduce(CombinationKey key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
            //sample: 30.641017,104.095475,0,2014-08-03 15:23:45
            int numOfZero = 0;
            int numOfOne = 0;
            List<String[]> list = new ArrayList<>();
            for (Text text : values) {
//                String[] splits = text.toString().split(",");
//                if ("0".equals(splits[2]))
//                    numOfZero++;
//                else
//                    numOfOne++;
//                list.add(splits);
                context.write(key.getFirstKey(),text);
            }
//            if (numOfZero < 1000 || numOfOne < 1000)
//                return;

//            try {
//                list.custom((o1, o2) -> {
//                    try {
//                        Date a = sdf.parse(o1[3]);
//                        Date b = sdf.parse(o2[3]);
//                        if (a.before(b)) {
//                            return -1;
//                        } else if (a.after(b)) {
//                            return 1;
//                        } else {
//                            return 0;
//                        }
//                    } catch (ParseException e) {
//                        e.printStackTrace();
//                        return 0;
//                    }
//                });
//            } catch (Exception e) {
//                e.printStackTrace();
//                System.out.println(list);
//                return;
//            }

//            boolean flag = false;//used to cutting trajectory
//            List<GPS> trajectory = new ArrayList<>();
//            for (String[] item : list) {
//
//                //taxi is busy, the GPS point is useful
//                //TODO
//                if ("0".equals(item[2])) {
//                    try {
//                        GPS current = new GPS(Double.parseDouble(item[0]), Double.parseDouble(item[1]), sdf.parse(item[3]));
//                        if (trajectory.size() != 0) {
//                            GPS last = trajectory.get(trajectory.size() - 1);
//                            //unit:s
//                            int interval = (int) (current.getTimestamp().getTime() - last.getTimestamp().getTime()) / 1000;
//                            //unit:m
//                            double distance = CommonUtil.distanceBetween(current, last);
//                            //unit:m/s
//                            double speed = distance / interval;
//
//                            //limit:120km/h
//                            if (speed <= 33.333) {
//                                if (distance > 5000 || interval > 10 * 60) {
//                                    List<Cell> cells = GridUtil.gridGPSSequence(trajectory);
//                                    //if the number of cells are less than 5, we suppose that this trajectory is noise data.
//                                    if (cells.size() >= 5) {
//                                        Put put = new Put(Bytes.toBytes(CommonUtil.getUUID()));
//                                        put.addColumn(HBaseConstant.COLUMN_FAMILY_INFO, HBaseConstant.COLUMN_ID, Bytes.toBytes(key.toString()));
//                                        put.addColumn(HBaseConstant.COLUMN_FAMILY_TRAJECTORY, HBaseConstant.COLUMN_TRAJECTORY, Bytes.toBytes(cells.toString()));
//                                        put.addColumn(HBaseConstant.COLUMN_FAMILY_TRAJECTORY, HBaseConstant.COLUMN_GPS, Bytes.toBytes(trajectory.toString()));
//                                        context.write(null, put);
//                                    }
//                                    trajectory.clear();
//                                } else {
//                                    trajectory.add(current);
//                                }
//                            }
//                        } else {
//                            trajectory.add(current);
//                        }
//                        flag = true;
//                    } catch (ParseException e) {
//                        e.printStackTrace();
//                    }
//
//                } else if (flag) {
//                    //taxi is empty now, means that one trajectory is generated
//                    List<Cell> cells = GridUtil.gridGPSSequence(trajectory);
//                    //if the number of cells are less than 5, we suppose that this trajectory is noise data.
//                    if (cells.size() >= 5) {
//                        Put put = new Put(Bytes.toBytes(CommonUtil.getUUID()));
//                        put.addColumn(HBaseConstant.COLUMN_FAMILY_INFO, HBaseConstant.COLUMN_ID, Bytes.toBytes(key.toString()));
//                        put.addColumn(HBaseConstant.COLUMN_FAMILY_TRAJECTORY, HBaseConstant.COLUMN_TRAJECTORY, Bytes.toBytes(cells.toString()));
//                        put.addColumn(HBaseConstant.COLUMN_FAMILY_TRAJECTORY, HBaseConstant.COLUMN_GPS, Bytes.toBytes(trajectory.toString()));
//                        context.write(null, put);
//                    }
//                    trajectory.clear();
//                    flag = false;
//                }
//            }
        }
    }


    public static void main(String[] args) throws Exception {
//        if (args.length < 1) {
//            System.out.println("Please input the filePath!");
//            return;
//        }
//        Configuration config = HBaseConfiguration.create();
        Job job = Job.getInstance(new Configuration(), "SortAndInsert");

        job.setJarByClass(SortAndInsert.class);
//        job.setInputFormatClass(com.hadoop.mapreduce.LzoTextInputFormat.class);
        job.setMapperClass(Map.class);
        job.setMapOutputKeyClass(CombinationKey.class);
        job.setMapOutputValueClass(Text.class);

        job.setReducerClass(Reduce.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(Text.class);

        job.setPartitionerClass(DefinedPartition.class);
        job.setSortComparatorClass(DefinedComparator.class);

//        job.setNumReduceTasks(36);

//        TableMapReduceUtil.initTableReducerJob(
//                HBaseConstant.TABLE_TRAJECTORY,      // output table
//                Reduce.class,             // reducer class
//                job);

        FileInputFormat.addInputPath(job, new Path("/Users/cbdog94/test.txt" ));
        FileOutputFormat.setOutputPath(job,new Path("/Users/cbdog94/result"));
        job.waitForCompletion(true);

    }
}
