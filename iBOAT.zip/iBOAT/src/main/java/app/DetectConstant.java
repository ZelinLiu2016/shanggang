package app;

import bean.Cell;

/**
 * Created by cbdog94 on 2017/4/21.
 */
public class DetectConstant {

//    public static Cell startPoint = new Cell("[109776,53554]");//陆家嘴
//    public static Cell endPoint = new Cell("[109873,53574]");//浦东机场

    public static Cell startPoint = new Cell("[109776,53525]");//五角场
    public static Cell endPoint = new Cell("[109756,53546]");//上海站

//    public static Cell startPoint = new Cell("[109775,53554]");//五角场
//    public static Cell endPoint = new Cell("[109793,53562]");//上海站

    public static String outputPath = "/Library/WebServer/Documents/used/";
}
