package algorithm;

import bean.GPS;
import org.apache.commons.math3.analysis.polynomials.PolynomialFunction;
import org.apache.commons.math3.distribution.NormalDistribution;
import org.apache.commons.math3.linear.MatrixUtils;
import org.apache.commons.math3.linear.RealMatrix;
import util.CommonUtil;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by cbdog94 on 2017/4/20.
 */
public class CustomDetection {

    private static final int DEGREE = 3;
    private static final double THRESHOLD = 0.9;

    public static double detect(List<List<GPS>> allNormalTrajectories, List<GPS> testTrajectory) {
        return detect(allNormalTrajectories, testTrajectory, THRESHOLD);
    }

    public static double detect(List<List<GPS>> allNormalTrajectories, List<GPS> testTrajectory, double threshold) {

        List<Double> distances = new ArrayList<>();//x
        List<Double> intervals = new ArrayList<>();//y

        Date startTime = testTrajectory.get(0).getTimestamp();
        Date endTime = testTrajectory.get(testTrajectory.size() - 1).getTimestamp();

        for (List<GPS> oneTrajectory : allNormalTrajectories) {
            GPS startPoint = oneTrajectory.get(0);
//            List<GPS> tmp = new ArrayList<>(oneTrajectory);
//            Collections.shuffle(tmp);
            for (int i = 0; i < oneTrajectory.size(); i++) {
                if (oneTrajectory.get(0).getTimestamp().getHours() < startTime.getHours() ||
                        oneTrajectory.get(oneTrajectory.size() - 1).getTimestamp().getHours() > endTime.getHours())
                    break;
                double dis = CommonUtil.distanceBetween(startPoint, oneTrajectory.get(i));
                double interval = (oneTrajectory.get(i).getTimestamp().getTime() - startPoint.getTimestamp().getTime()) / 1000;
//                if(interval<0){
//                    System.out.println(tmp);
//                    break;
//                }
                distances.add(dis);
                intervals.add(interval);
            }
        }

        if (distances.size() == 0)
            return 1;

        //Fitted the data set by maximum likelihood estimation
        double[][] x = new double[distances.size()][DEGREE + 1];
        for (int i = 0; i < distances.size(); i++) {
            for (int j = 0; j < DEGREE + 1; j++) {
                x[i][j] = Math.pow(distances.get(i), j);
            }
        }

        double[] t = new double[intervals.size()];
        for (int i = 0; i < intervals.size(); i++) {
            t[i] = intervals.get(i);
        }

        RealMatrix X = MatrixUtils.createRealMatrix(x);
        RealMatrix T = MatrixUtils.createColumnRealMatrix(t);
        RealMatrix XT = X.transpose();
        RealMatrix TT = T.transpose();
        double[] w = MatrixUtils.inverse(XT.multiply(X)).multiply(XT).multiply(T).getColumn(0);
        double e = (TT.multiply(T).subtract(TT.multiply(X).multiply(MatrixUtils.createColumnRealMatrix(w)))).getEntry(0, 0) / x.length;
//        System.out.println(new Gson().toJson(w));
//        System.out.println(e);

//        System.out.println("-------------------------");


        PolynomialFunction poly = new PolynomialFunction(w);

//        List<Double> tDistances = new ArrayList<>();//x
//        List<Double> tIntervals = new ArrayList<>();//y
        List<GPS> anomalyPoints = new ArrayList<>();

        GPS startPos = testTrajectory.get(0);
        for (GPS gps : testTrajectory) {
            double dis = CommonUtil.distanceBetween(startPos, gps);
            double interval = (gps.getTimestamp().getTime() - startTime.getTime()) / 1000;
            double predict = poly.value(dis);

            NormalDistribution distribution = new NormalDistribution(predict * 1.1, Math.sqrt(e));

//            tDistances.add(dis);
//            tIntervals.add(interval);
//            System.out.println(distribution.density(interval));
//            System.out.println(distribution.cumulativeProbability(interval));

            if (distribution.cumulativeProbability(interval) > threshold)
                anomalyPoints.add(gps);

//            PolynomialFunction polynomialFunction
        }


//        System.out.println("-------------------------");

//        System.out.println(new Gson().toJson(distances));
//        System.out.println(new Gson().toJson(intervals));
//
//        System.out.println(new Gson().toJson(tDistances));
//        System.out.println(new Gson().toJson(tIntervals));
//
//        System.out.println("-------------------------");

        return anomalyPoints.size() * 1.0 / testTrajectory.size();

    }

//    private static double
}
