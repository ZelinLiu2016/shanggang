import algorithm.iBOATDetection;
import app.bean.TrajectoryInfo;
import bean.Cell;
import bean.GPS;
import hbase.TrajectoryUtil;
import org.apache.commons.io.FileUtils;
import util.CommonUtil;
import util.TileSystem;

import java.io.File;
import java.io.IOException;
import java.util.*;

/**
 * Created by cbdog94 on 2017/4/19.
 */
public class Test2 {
    public static void main(String[] args) throws IOException {


        Cell startPoint = TileSystem.GPSToTile(new GPS(31.3021457537295, 121.51120542282582, null));
        Cell endPoint = TileSystem.GPSToTile(new GPS(31.249278746623446, 121.4526714546335, null));
        String fileName = "2222.txt";
        double threshold = iBOATDetection.threshold;


        Map<String, List<Cell>> allTrajectories = TrajectoryUtil.getAllTrajectoryCells(startPoint, endPoint);

        System.out.println("threshold:" + threshold);
        System.out.println("all size:" + allTrajectories.size());
        Set<String> iBOATSetN = new HashSet<>();

        long total = 0;
        for (String trajectoryID : allTrajectories.keySet()) {

            List<GPS> testTrajectory = TrajectoryUtil.getTrajectoryGPSPoints(trajectoryID);
            testTrajectory = CommonUtil.removeExtraGPS(testTrajectory, startPoint, endPoint);
            if (testTrajectory == null || testTrajectory.size() == 0) {
                continue;
            }
            Map<String, List<Cell>> tmpTrajectories = new HashMap<>(allTrajectories);
            tmpTrajectories.remove(trajectoryID);

            long start = System.currentTimeMillis();
            double score = iBOATDetection.iBOAT(testTrajectory, new ArrayList<>(tmpTrajectories.values()), threshold);
            long end = System.currentTimeMillis();
            total += end - start;

            TrajectoryInfo trajectoryInfo = new TrajectoryInfo();
            trajectoryInfo.taxiId = trajectoryID;
            trajectoryInfo.score = score;
            trajectoryInfo.normal = score < 0.1;

            if (trajectoryInfo.normal)
                iBOATSetN.add(trajectoryID);


        }

        System.out.println(total);

        List<Double> anomalyDistance = new ArrayList<>();
        List<Integer> anomalyTime = new ArrayList<>();

        List<String> anomaly = FileUtils.readLines(FileUtils.getFile(fileName));

        for (String trajectoryID : anomaly) {
            List<GPS> testTrajectory = TrajectoryUtil.getTrajectoryGPSPoints(trajectoryID);
            testTrajectory = CommonUtil.removeExtraGPS(testTrajectory, startPoint, endPoint);
            if (testTrajectory == null || testTrajectory.size() == 0) {
                continue;
            }
            GPS start = testTrajectory.get(0);
            for (GPS gps : testTrajectory) {

                if ((gps.getTimestamp().getTime() - start.getTimestamp().getTime()) < 0)
                    break;

                anomalyDistance.add(CommonUtil.distanceBetween(start, gps));
                anomalyTime.add((int) (gps.getTimestamp().getTime() - start.getTimestamp().getTime()) / 1000);
            }
        }

        List<Double> normalDistance = new ArrayList<>();
        List<Integer> normalTime = new ArrayList<>();


        for (String trajectoryID : iBOATSetN) {
            List<GPS> testTrajectory = TrajectoryUtil.getTrajectoryGPSPoints(trajectoryID);
            testTrajectory = CommonUtil.removeExtraGPS(testTrajectory, startPoint, endPoint);
            if (testTrajectory == null || testTrajectory.size() == 0) {
                continue;
            }
            GPS start = testTrajectory.get(0);
            if ((testTrajectory.get(testTrajectory.size() - 1).getTimestamp().getTime() - start.getTimestamp().getTime()) > 40 * 60 * 1000)
                continue;
            for (GPS gps : testTrajectory) {
                if ((gps.getTimestamp().getTime() - start.getTimestamp().getTime()) < 0)
                    break;

                normalDistance.add(CommonUtil.distanceBetween(start, gps));
                normalTime.add((int) (gps.getTimestamp().getTime() - start.getTimestamp().getTime()) / 1000);
            }
        }

        FileUtils.write(new File("scatter.txt"), anomalyDistance.toString(), false);
        FileUtils.write(new File("scatter.txt"), anomalyTime.toString(), true);
        FileUtils.write(new File("scatter.txt"), normalDistance.toString(), true);
        FileUtils.write(new File("scatter.txt"), normalTime.toString(), true);


    }
}
