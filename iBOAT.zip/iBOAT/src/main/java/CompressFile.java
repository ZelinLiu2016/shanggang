import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.*;
import org.apache.hadoop.io.IOUtils;
import org.apache.hadoop.io.compress.BZip2Codec;
import org.apache.hadoop.io.compress.CompressionOutputStream;

/**
 * Test the Compress function of Hadoop
 */
public class CompressFile {
    public static void main(String[] args) throws Exception {
//        Class<?> codecClass=Class.forName(codecClassName);
        Configuration conf = new Configuration();

        FileSystem fs = FileSystem.get(conf);
//        CompressionCodec codec= (CompressionCodec)ReflectionUtils.newInstance(codecClass,conf);
        BZip2Codec codec = new BZip2Codec();
        codec.setConf(conf);


        System.out.println("compress start!");

        for (FileStatus fileStatus : fs.listStatus(new Path("/input/data/"))) {
            System.out.println("dealing  " + fileStatus.getPath());
            FSDataInputStream in = fs.open(fileStatus.getPath());
            FSDataOutputStream outputStream = fs.create(new Path("/input/compressData/" + fileStatus.getPath().getName().replace(".txt", "") + ".bz2"));
            CompressionOutputStream out = codec.createOutputStream(outputStream);
            IOUtils.copyBytes(in, out, conf);
            IOUtils.closeStream(in);
            IOUtils.closeStream(out);
        }


        System.out.println("compress ok!");

    }
}
