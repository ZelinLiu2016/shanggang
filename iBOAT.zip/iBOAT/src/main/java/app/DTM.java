package app;

import algorithm.CustomDetection;
import algorithm.iBOATDetection;
import app.bean.TrajectoryInfo;
import bean.Cell;
import bean.GPS;
import hbase.TrajectoryUtil;
import org.apache.commons.io.FileUtils;
import util.CommonUtil;
import util.TileSystem;

import java.io.IOException;
import java.util.*;

/**
 * Distance-Time Model
 */
public class DTM {


    public static void main(String[] args) throws IOException {

        Cell startPoint = DetectConstant.startPoint;
        Cell endPoint = DetectConstant.endPoint;
        String fileName = "";
        double threshold = 0.9;

        if (args.length == 4) {
            String[] start = args[0].split(",");
            String[] end = args[1].split(",");
            startPoint = TileSystem.GPSToTile(new GPS(Double.parseDouble(start[0]), Double.parseDouble(start[1]), null));
            endPoint = TileSystem.GPSToTile(new GPS(Double.parseDouble(end[0]), Double.parseDouble(end[1]), null));
            fileName = args[2];
            threshold = Double.parseDouble(args[3]);
        } else {
            System.out.println("please input startLat,startLng endLat,endLng anomalyFile");
            return;
        }

        Map<String, List<Cell>> allTrajectories = TrajectoryUtil.getAllTrajectoryCells(startPoint, endPoint);

        System.out.println("all size:" + allTrajectories.size());

        Set<String> iBOATSetN = new HashSet<>();
        Set<String> iBOATSetA = new HashSet<>();

        long totalIBOAT = 0;

        for (String id : allTrajectories.keySet()) {

            List<GPS> testTrajectory = TrajectoryUtil.getTrajectoryGPSPoints(id);
            testTrajectory = CommonUtil.removeExtraGPS(testTrajectory, startPoint, endPoint);
            if (testTrajectory == null || testTrajectory.size() == 0) {
                continue;
            }

            Map<String, List<Cell>> tmpTrajectories = new HashMap<>(allTrajectories);
            tmpTrajectories.remove(id);

            long start = System.currentTimeMillis();
            double result = iBOATDetection.iBOAT(testTrajectory, new ArrayList<>(tmpTrajectories.values()));
            long end = System.currentTimeMillis();

            totalIBOAT += end - start;

            if (result < 0.1)
                iBOATSetN.add(id);
            else
                iBOATSetA.add(id);
        }

        System.out.println("TotalTime:" + totalIBOAT);
        double perTime = totalIBOAT * 1.0 / (iBOATSetN.size() + iBOATSetA.size());
        System.out.println("PerTime:" + perTime);
        System.out.println("finish iBOAT!");

        System.out.println("iBOAT Normal size:" + iBOATSetN.size());
        System.out.println("iBOAT Anomaly size:" + iBOATSetA.size());

        List<String> anomaly = FileUtils.readLines(FileUtils.getFile(fileName));
        Set<String> preAnomaly = new HashSet<>(iBOATSetA);
        Set<String> preNormal = new HashSet<>(iBOATSetN);
        int allAnomaly = preAnomaly.size();
        preAnomaly.retainAll(anomaly);
        System.out.println("TP:" + preAnomaly.size());
        System.out.println("FP:" + (allAnomaly - preAnomaly.size()));

        int allNormal = preNormal.size();
        preNormal.retainAll(anomaly);

        System.out.println("FN:" + preNormal.size());
        System.out.println("TN:" + (allNormal - preNormal.size()));

        int TP = preAnomaly.size();
        int FP = allAnomaly - preAnomaly.size();
        int FN = preNormal.size();
        int TN = allNormal - preNormal.size();

        System.out.println("TPR:" + TP * 1.0 / (TP + FN));
        System.out.println("FPR:" + FP * 1.0 / (FP + TN));

        System.out.println("---------------");

        List<List<GPS>> allList = new ArrayList<>();
        for (String trajectoryID : iBOATSetN) {
            List<GPS> trajectory = TrajectoryUtil.getTrajectoryGPSPoints(trajectoryID);
            trajectory = CommonUtil.removeExtraGPS(trajectory, startPoint, endPoint);
            if (trajectory == null || trajectory.size() == 0) {
                continue;
            }
            allList.add(trajectory);
        }

//        List<TrajectoryInfo> trajectoryInfos = new ArrayList<>();
        Set<String> customNormal = new HashSet<>();
        long totalDTM = 0;
        for (String trajectoryID : iBOATSetA) {
            List<GPS> trajectory = TrajectoryUtil.getTrajectoryGPSPoints(trajectoryID);
            trajectory = CommonUtil.removeExtraGPS(trajectory, startPoint, endPoint);
            if (trajectory == null || trajectory.size() == 0) {
                continue;
            }

            long start = System.currentTimeMillis();
            double score = CustomDetection.detect(allList, trajectory, threshold);
            long end = System.currentTimeMillis();
            totalDTM += end - start;

            TrajectoryInfo trajectoryInfo = new TrajectoryInfo();
            trajectoryInfo.taxiId = trajectoryID;
            trajectoryInfo.score = score;
            trajectoryInfo.normal = score < 0.1;
            trajectoryInfo.trajectory = trajectory;

            if (trajectoryInfo.normal)
                customNormal.add(trajectoryID);

//            trajectoryInfos.add(trajectoryInfo);
        }

        System.out.println("TotalTime:" + totalDTM);
        System.out.println("PerTime:" + (totalDTM * 1.0 / iBOATSetA.size() + perTime));


        customNormal.addAll(iBOATSetN);//DTM检测认为正常的
        Set<String> FNSet = new HashSet<>(customNormal);
        FNSet.retainAll(anomaly);//漏报的
        FN = FNSet.size();
        TN = customNormal.size() - FN;
        TP = anomaly.size() - FN;
        FP = allAnomaly + allNormal - FN - TP - TN;


        System.out.println("TN:" + TN);
        System.out.println("FP:" + FP);
        System.out.println("TP:" + TP);
        System.out.println("FN:" + FN);

        System.out.println("TPR:" + TP * 1.0 / (TP + FN));
        System.out.println("FPR:" + FP * 1.0 / (FP + TN));

//        File file = FileUtils.getFile(DetectConstant.outputPath + "custom.json");
//        String content = new Gson().toJson(trajectoryInfos);
//        FileUtils.write(file, content, false);
    }


}
