package hbase;

import constant.HBaseConstant;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.Cell;
import org.apache.hadoop.hbase.CellUtil;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.*;
import org.apache.hadoop.hbase.util.Bytes;

import java.io.IOException;

/**
 * Test how to access HBase by JAVA API
 */
public class Test {

    public static void main(String[] args) throws IOException {
        HBaseUtil hBaseUtil=new HBaseUtil();


        Table table = hBaseUtil.getConnection().getTable(TableName.valueOf(HBaseConstant.TABLE_TRAJECTORY));

        //put
//        Put put = new Put(Bytes.toBytes("row-3"));
//        put.addColumn(Bytes.toBytes("colfam1"), Bytes.toBytes("q5"), Bytes.toBytes("[111,11]"));
//        table.put(put);

        //get
//        Get get = new Get(Bytes.toBytes("row-3"));
//        get.addFamily(Bytes.toBytes("colfam1"));
//        Result result = table.get(get);
//        for (Cell cell : result.listCells()) {
//            System.out.println(Bytes.toString(CellUtil.cloneValue(cell)));
//        }
//
//        while (result.advance()) {
//            System.out.println(Bytes.toString(CellUtil.cloneValue(result.current())));
//        }

        //scan
        Scan scan = new Scan();
        scan.addColumn(HBaseConstant.COLUMN_FAMILY_INFO,HBaseConstant.COLUMN_DISTANCE);
        scan.setMaxResultSize(10);
        scan.setMaxResultsPerColumnFamily(10);
//        scan.addColumn(CF, ATTR);
//        scan.setRowPrefixFilter(Bytes.toBytes("row"));
        ResultScanner rs = table.getScanner(scan);
        try {
            for (Result r = rs.next(); r != null; r = rs.next()) {
                System.out.println(Bytes.toString(r.getRow()));
                for (Cell cell : r.listCells()) {
                    System.out.println(Bytes.toDouble(CellUtil.cloneValue(cell)));
                }
            }
        } finally {
            rs.close();  // always close the ResultScanner!
        }




    }
}
